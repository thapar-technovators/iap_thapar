# iap_thapar
The online management portal of six months semester training.
